### github url

```
https://github.com/harryhare/udacity_cloud_ops_course/tree/master/l1

```

### websit url

```
http://d15zks29kg5wqc.cloudfront.net/index.html
```

### screenshots

* s3 bucket
![](s3_bulcket.png)

* files upload
![](s3_files.png)

* website hosting
![](s3_website_hosting.png)

* policy
![](s3_policy)

* cloudfront configuration
![](cloudfront_origin.png)

* website screenshots
![](website.png)


